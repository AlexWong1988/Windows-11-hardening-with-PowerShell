#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Windows 11 Hardening Script — CIS Benchmark L1 + Microsoft Security Baseline
.DESCRIPTION
    Applies security hardening controls aligned to:
      - CIS Microsoft Windows 11 Benchmark v3.0 (Level 1)
      - Microsoft Windows 11 Security Baseline (November 2023)
    Covers: Account Policy, Audit Policy, Windows Defender, Network, Services,
            Registry, BitLocker readiness check, and User Rights Assignment.
.NOTES
    Author      : Alex Wong / LLSG Digital Services
    Version     : 1.0
    Tested On   : Windows 11 22H2 / 23H2
    Run As      : Local Administrator or Domain Admin
    DISCLAIMER  : Test in a non-production environment first.
                  Some settings may conflict with existing GPOs.
    References  :
      https://www.cisecurity.org/benchmark/microsoft_windows_desktop
      https://www.microsoft.com/en-us/download/details.aspx?id=55319
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'SilentlyContinue'

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────
$LogFile = "$env:SYSTEMDRIVE\HardeningLog_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
$Results = [System.Collections.Generic.List[PSCustomObject]]::new()

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts][$Level] $Message"
    Add-Content -Path $LogFile -Value $line
    switch ($Level) {
        'INFO'  { Write-Host $line -ForegroundColor Cyan }
        'OK'    { Write-Host $line -ForegroundColor Green }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
    }
}

function Set-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        [object]$Value,
        [string]$Type = 'DWord',
        [string]$Description = ''
    )
    try {
        if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
        Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type $Type -Force
        $Results.Add([PSCustomObject]@{ Control=$Description; Status='Applied'; Detail="$Path\$Name = $Value" })
        Write-Log "Applied: $Description" 'OK'
    } catch {
        $Results.Add([PSCustomObject]@{ Control=$Description; Status='FAILED'; Detail=$_.Exception.Message })
        Write-Log "FAILED: $Description — $($_.Exception.Message)" 'ERROR'
    }
}

function Disable-ServiceSafe {
    param([string]$Name, [string]$Description)
    try {
        $svc = Get-Service -Name $Name -ErrorAction Stop
        if ($svc.Status -ne 'Stopped') { Stop-Service -Name $Name -Force }
        Set-Service -Name $Name -StartupType Disabled
        $Results.Add([PSCustomObject]@{ Control=$Description; Status='Disabled'; Detail="Service: $Name" })
        Write-Log "Disabled service: $Name — $Description" 'OK'
    } catch {
        $Results.Add([PSCustomObject]@{ Control=$Description; Status='Not Found/Error'; Detail=$_.Exception.Message })
        Write-Log "Service not found or error: $Name" 'WARN'
    }
}

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — ACCOUNT POLICIES  (CIS 1.x)
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 1: Account Policies ===' 'INFO'

# 1.1 Password Policy
net accounts /minpwlen:14            | Out-Null   # CIS 1.1.1  Min password length ≥ 14
net accounts /maxpwage:60            | Out-Null   # CIS 1.1.2  Max password age ≤ 60 days
net accounts /minpwage:1             | Out-Null   # CIS 1.1.3  Min password age ≥ 1
net accounts /uniquepw:24            | Out-Null   # CIS 1.1.4  Enforce password history 24
net accounts /lockoutthreshold:5     | Out-Null   # CIS 1.2.1  Account lockout threshold ≤ 5
net accounts /lockoutduration:15     | Out-Null   # CIS 1.2.2  Lockout duration ≥ 15 min
net accounts /lockoutwindow:15       | Out-Null   # CIS 1.2.3  Reset lockout counter ≥ 15 min
Write-Log 'Password and lockout policy applied via net accounts' 'OK'
$Results.Add([PSCustomObject]@{ Control='Account/Password Policy'; Status='Applied'; Detail='net accounts settings' })

# Disable Guest account (CIS 2.3.1.2)
net user Guest /active:no | Out-Null
Write-Log 'Guest account disabled' 'OK'
$Results.Add([PSCustomObject]@{ Control='Guest Account Disabled'; Status='Applied'; Detail='CIS 2.3.1.2' })

# Rename Administrator account (CIS 2.3.1.1) — renames to a less obvious name
$adminSID = (Get-LocalUser | Where-Object { $_.SID -like 'S-1-5-*-500' }).Name
if ($adminSID -and $adminSID -eq 'Administrator') {
    Rename-LocalUser -Name 'Administrator' -NewName 'LocalAdmin_Mgr'
    Write-Log "Built-in Administrator renamed to LocalAdmin_Mgr" 'OK'
    $Results.Add([PSCustomObject]@{ Control='Rename Administrator Account'; Status='Applied'; Detail='CIS 2.3.1.1' })
}

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — WINDOWS DEFENDER / ANTIVIRUS  (MS Baseline + CIS 18.x)
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 2: Windows Defender & Antivirus ===' 'INFO'

$defBase = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender'

Set-RegistryValue "$defBase"                       'DisableAntiSpyware'        0  'DWord' 'CIS 18.9.47.4 — Enable Defender antispyware'
Set-RegistryValue "$defBase\Real-Time Protection"  'DisableRealtimeMonitoring' 0  'DWord' 'CIS 18.9.47.9 — Enable real-time monitoring'
Set-RegistryValue "$defBase\Real-Time Protection"  'DisableBehaviorMonitoring' 0  'DWord' 'CIS 18.9.47.5 — Enable behaviour monitoring'
Set-RegistryValue "$defBase\Real-Time Protection"  'DisableIOAVProtection'     0  'DWord' 'CIS 18.9.47.7 — Enable scan of downloaded files'
Set-RegistryValue "$defBase\Spynet"                'SpynetReporting'           2  'DWord' 'CIS 18.9.47.12 — MAPS membership (Advanced)'
Set-RegistryValue "$defBase\Spynet"                'SubmitSamplesConsent'      1  'DWord' 'CIS 18.9.47.13 — Send file samples automatically'
Set-RegistryValue "$defBase\MpEngine"              'MpEnablePus'               1  'DWord' 'CIS 18.9.47.8 — Detect PUA'
Set-RegistryValue "$defBase\Windows Defender Exploit Guard\Network Protection" `
                                                   'EnableNetworkProtection'   1  'DWord' 'CIS 18.9.47.2 — Enable Network Protection'
# Enable Defender Cloud-delivered protection
Set-MpPreference -MAPSReporting Advanced -SubmitSamplesConsent SendSafeSamples `
                 -EnableNetworkProtection Enabled -PUAProtection Enabled `
                 -DisableRealtimeMonitoring $false 2>$null
Write-Log 'Defender preferences applied via Set-MpPreference' 'OK'

# Attack Surface Reduction (ASR) rules — CIS 18.9.47.1 / MS Baseline
$ASRRules = @{
    'BE9BA2D9-53EA-4CDC-84E5-9B1EEEE46550' = 1   # Block executable content from email
    'D4F940AB-401B-4EFC-AADC-AD5F3C50688A' = 1   # Block Office child processes
    '3B576869-A4EC-4529-8536-B80A7769E899' = 1   # Block Office executable content
    '75668C1F-73B5-4CF0-BB93-3ECF5CB7CC84' = 1   # Block Office injecting into other processes
    'D3E037E1-3EB8-44C8-A917-57927947596D' = 1   # Block JS/VBS launching downloaded exec
    '5BEB7EFE-FD9A-4556-801D-275E5FFC04CC' = 1   # Block obfuscated scripts
    '92E97FA1-2EDF-4476-BDD6-9DD0B4DDDC7B' = 1   # Block Win32 API calls from macros
    '01443614-CD74-433A-B99E-2ECDC07BFC25' = 1   # Block executable files (prevalence/age)
    'C1DB55AB-C21A-4637-BB3F-A12568109D35' = 1   # Use advanced ransomware protection
    '9E6C4E1F-7D60-472F-BA1A-A39EF669E4B0' = 1   # Block credentials stealing (LSASS)
    'D1E49AAC-8F56-4280-B9BA-993A6D77406C' = 1   # Block process creations from PSExec/WMI
    'B2B3F03D-6A65-4F7B-A9C7-1C7EF74A9BA4' = 1   # Block untrusted USB processes
    '26190899-1602-49E8-8B27-EB1D0A1CE869' = 1   # Block Office communication child processes
    '7674BA52-37EB-4A4F-A9A1-F0F9A1619A2C' = 1   # Block Adobe Reader child processes
    'E6DB77E5-3DF2-4CF1-B95A-636979351E5B' = 1   # Block persistence through WMI
}
try {
    Add-MpPreference -AttackSurfaceReductionRules_Ids   ($ASRRules.Keys)   `
                     -AttackSurfaceReductionRules_Actions ($ASRRules.Values) 2>$null
    Write-Log 'ASR rules applied (15 rules, Enforce mode)' 'OK'
    $Results.Add([PSCustomObject]@{ Control='ASR Rules (15)'; Status='Applied'; Detail='Enforce mode' })
} catch {
    Write-Log "ASR rules failed: $($_.Exception.Message)" 'WARN'
    $Results.Add([PSCustomObject]@{ Control='ASR Rules (15)'; Status='FAILED'; Detail=$_.Exception.Message })
}

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — WINDOWS FIREWALL  (CIS 9.x)
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 3: Windows Firewall ===' 'INFO'

Set-NetFirewallProfile -Profile Domain,Public,Private `
    -Enabled True -DefaultInboundAction Block -DefaultOutboundAction Allow `
    -NotifyOnListen True -LogAllowed True -LogBlocked True -LogMaxSizeKilobytes 16384
Write-Log 'Firewall enabled on all profiles — inbound blocked by default' 'OK'
$Results.Add([PSCustomObject]@{ Control='Windows Firewall (All Profiles)'; Status='Applied'; Detail='CIS 9.1/9.2/9.3' })

# Disable NetBIOS over TCP/IP (CIS)
$adapters = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True"
foreach ($a in $adapters) { $a.SetTCPIPNetBIOS(2) | Out-Null }
Write-Log 'NetBIOS over TCP/IP disabled on all adapters' 'OK'
$Results.Add([PSCustomObject]@{ Control='Disable NetBIOS over TCP/IP'; Status='Applied'; Detail='All adapters' })

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 — AUDIT POLICY  (CIS 17.x)
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 4: Advanced Audit Policy ===' 'INFO'

$auditCategories = @(
    # Subcategory                                     Success Failure
    @('Logon',                                          $true,  $true ),   # CIS 17.5.1
    @('Logoff',                                         $true,  $false),   # CIS 17.5.2
    @('Account Lockout',                                $false, $true ),   # CIS 17.5.3
    @('Special Logon',                                  $true,  $false),   # CIS 17.5.4
    @('Credential Validation',                          $true,  $true ),   # CIS 17.1.1
    @('Account Management',                             $true,  $true ),   # CIS 17.2.x
    @('Security Group Management',                      $true,  $true ),
    @('Process Creation',                               $true,  $false),   # CIS 17.3.1
    @('Audit Policy Change',                            $true,  $true ),   # CIS 17.7.1
    @('Sensitive Privilege Use',                        $true,  $true ),   # CIS 17.6.1
    @('IPsec Driver',                                   $true,  $true ),
    @('Security State Change',                          $true,  $false),
    @('Security System Extension',                      $true,  $false),
    @('System Integrity',                               $true,  $true ),
    @('Other Object Access Events',                     $false, $true ),   # CIS 17.4.1
    @('Removable Storage',                              $true,  $true ),
    @('File Share',                                     $true,  $true ),
    @('Kerberos Authentication Service',                $true,  $true ),
    @('Other Account Logon Events',                     $true,  $true ),
    @('Directory Service Access',                       $false, $true )
)

foreach ($cat in $auditCategories) {
    $name    = $cat[0]
    $success = if ($cat[1]) { 'enable' } else { 'disable' }
    $failure = if ($cat[2]) { 'enable' } else { 'disable' }
    auditpol /set /subcategory:"$name" /success:$success /failure:$failure 2>$null | Out-Null
}
Write-Log 'Advanced Audit Policy configured (20 subcategories)' 'OK'
$Results.Add([PSCustomObject]@{ Control='Advanced Audit Policy'; Status='Applied'; Detail='CIS 17.x — 20 subcategories' })

# Enable command-line process auditing  (CIS 17.3.1)
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' `
    'ProcessCreationIncludeCmdLine_Enabled' 1 'DWord' 'CIS 17.3.1 — Audit command line in process creation'

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 — USER RIGHTS ASSIGNMENT  (CIS 2.2.x via secedit / Registry)
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 5: User Rights Assignment ===' 'INFO'

# Export, modify, import secedit template
$seceditInf = "$env:TEMP\harden_secedit.inf"
$seceditDb  = "$env:TEMP\harden_secedit.sdb"
secedit /export /cfg $seceditInf /quiet 2>$null

$infContent = @"
[Unicode]
Unicode=yes
[Privilege Rights]
; CIS 2.2.2  — Access this computer from the network: Administrators only (domain: add authenticated users as needed)
SeNetworkLogonRight = *S-1-5-32-544
; CIS 2.2.4  — Act as part of OS: no one
SeTcbPrivilege =
; CIS 2.2.5  — Adjust memory quotas for a process
SeIncreaseQuotaPrivilege = *S-1-5-19,*S-1-5-20,*S-1-5-32-544
; CIS 2.2.10 — Create symbolic links: Administrators only
SeCreateSymbolicLinkPrivilege = *S-1-5-32-544
; CIS 2.2.11 — Debug programs: no one (or Administrators for dev machines — comment out)
SeDebugPrivilege =
; CIS 2.2.13 — Deny access to this computer from the network: include Guests
SeDenyNetworkLogonRight = *S-1-5-32-546
; CIS 2.2.14 — Deny logon as batch job: Guests
SeDenyBatchLogonRight = *S-1-5-32-546
; CIS 2.2.15 — Deny logon as service: Guests
SeDenyServiceLogonRight = *S-1-5-32-546
; CIS 2.2.16 — Deny logon locally: Guests
SeDenyInteractiveLogonRight = *S-1-5-32-546
; CIS 2.2.24 — Force shutdown from a remote system: Administrators
SeRemoteShutdownPrivilege = *S-1-5-32-544
; CIS 2.2.26 — Impersonate a client after authentication
SeImpersonatePrivilege = *S-1-5-19,*S-1-5-20,*S-1-5-32-544,*S-1-5-6
; CIS 2.2.38 — Take ownership of files: Administrators
SeTakeOwnershipPrivilege = *S-1-5-32-544
[Version]
signature="\$CHICAGO\$"
Revision=1
"@

Set-Content -Path $seceditInf -Value $infContent -Encoding Unicode
secedit /configure /db $seceditDb /cfg $seceditInf /quiet 2>$null
Remove-Item $seceditInf, $seceditDb -Force -ErrorAction SilentlyContinue
Write-Log 'User Rights Assignment applied via secedit' 'OK'
$Results.Add([PSCustomObject]@{ Control='User Rights Assignment'; Status='Applied'; Detail='CIS 2.2.x via secedit' })

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 6 — SECURITY OPTIONS / REGISTRY  (CIS 2.3.x, 18.x)
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 6: Security Options & Registry Hardening ===' 'INFO'

# --- LSA / Credentials ---
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'RunAsPPL'                     1  'DWord' 'CIS 18.3.1 — LSA Protection (RunAsPPL)'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'RestrictAnonymous'            1  'DWord' 'CIS 2.3.10.2 — Restrict anonymous SAM'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'RestrictAnonymousSAM'         1  'DWord' 'CIS 2.3.10.3 — Restrict anonymous SAM enumeration'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'LimitBlankPasswordUse'        1  'DWord' 'CIS 2.3.1.4 — Limit blank password use'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'NoLMHash'                     1  'DWord' 'CIS 2.3.11.3 — Do not store LM Hash'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'LmCompatibilityLevel'         5  'DWord' 'CIS 2.3.11.7 — LAN Manager auth: NTLMv2 only'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'NtlmMinClientSec'     537395200  'DWord' 'CIS 2.3.11.8 — Min session security NTLM (128-bit + NTLMv2)'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'NtlmMinServerSec'     537395200  'DWord' 'CIS 2.3.11.9 — Min session security NTLM server'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'DisableDomainCreds'           1  'DWord' 'CIS 2.3.11.4 — Network access: do not allow storage of passwords'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'EveryoneIncludesAnonymous'    0  'DWord' 'CIS 2.3.10.5 — Do not let Everyone include Anonymous'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' 'NTLMMinClientSec' 537395200 'DWord' 'NTLMv2 min client security (MSV1_0)'

# --- SMB / Network ---
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' 'SMB1'     0  'DWord' 'CIS — Disable SMBv1'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' 'RequireSecuritySignature' 1 'DWord' 'CIS 2.3.8.3 — Require SMB server signing'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' 'RequireSecuritySignature' 1 'DWord' 'CIS 2.3.8.1 — Require SMB client signing'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' 'EnableSecuritySignature'   1 'DWord' 'CIS 2.3.8.2 — Enable SMB client signing'
# Disable SMBv1 via feature
Disable-WindowsOptionalFeature -Online -FeatureName 'SMB1Protocol' -NoRestart 2>$null | Out-Null
Write-Log 'SMBv1 disabled via feature and registry' 'OK'

# --- WDigest ---
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' 'UseLogonCredential' 0 'DWord' 'CIS 18.3.7 — WDigest: disable plain-text credential caching'

# --- UAC ---
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'EnableLUA'                1  'DWord' 'CIS 2.3.17.1 — Enable UAC'
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'ConsentPromptBehaviorAdmin' 2 'DWord' 'CIS 2.3.17.2 — UAC: prompt for consent (secure desktop)'
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'ConsentPromptBehaviorUser' 0 'DWord' 'CIS 2.3.17.3 — UAC: deny elevation for standard users'
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'EnableInstallerDetection' 1 'DWord' 'CIS 2.3.17.5 — Detect application installs'
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'EnableVirtualization'     1 'DWord' 'CIS 2.3.17.7 — Virtualize file/registry writes'
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'PromptOnSecureDesktop'    1 'DWord' 'CIS 2.3.17.6 — UAC on secure desktop'

# --- Remote Desktop ---
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server'                'fDenyTSConnections'        1  'DWord' 'CIS — Disable RDP (enable manually if needed)'
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' 'UserAuthentication' 1  'DWord' 'CIS 18.9.65.3.9.1 — NLA required for RDP'

# --- Windows Remote Management ---
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service' 'AllowBasic'             0  'DWord' 'CIS 18.9.102.1.1 — Disable WinRM basic auth'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client' 'AllowBasic'              0  'DWord' 'CIS 18.9.102.2.1 — Disable WinRM client basic auth'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client' 'AllowUnencryptedTraffic' 0  'DWord' 'CIS 18.9.102.2.3 — Disable WinRM unencrypted traffic'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client' 'AllowDigest'             0  'DWord' 'CIS 18.9.102.2.2 — Disable WinRM digest auth'

# --- AutoPlay / AutoRun ---
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' 'NoAutoplayfornonVolume'       1  'DWord' 'CIS 18.9.8.1 — Disable AutoPlay non-volume devices'
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'NoDriveTypeAutoRun' 255 'DWord' 'CIS 18.9.8.3 — Disable AutoRun all drives'
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'NoAutorun'     1  'DWord' 'CIS 18.9.8.2 — Disable AutoRun default'

# --- Credential Guard ---
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' 'EnableVirtualizationBasedSecurity' 1 'DWord' 'MS Baseline — Enable VBS (Credential Guard pre-req)'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' 'RequirePlatformSecurityFeatures'   3 'DWord' 'MS Baseline — Require Secure Boot + DMA protection'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' 'LsaCfgFlags'                       1 'DWord' 'MS Baseline — Enable Credential Guard'

# --- Secure Boot / UEFI related indicators ---
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' 'HVCIMATRequired' 1 'DWord' 'MS Baseline — HVCI: Memory Integrity'

# --- Event Log sizes ---
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Application' 'MaxSize'  'DWORD' 'DWord' 'CIS 18.9.27.1.1 — App event log ≥ 32MB'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Application' 'MaxSize'  32768   'DWord' 'CIS 18.9.27.1.1 — App log max size'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Security'    'MaxSize'  196608  'DWord' 'CIS 18.9.27.2.1 — Security log max size ≥ 196MB'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\System'      'MaxSize'  32768   'DWord' 'CIS 18.9.27.3.1 — System log max size ≥ 32MB'

# --- Screen lock / password on wake ---
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51' 'ACSettingIndex'  1 'DWord' 'CIS — Require password on wake (plugged in)'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51' 'DCSettingIndex'  1 'DWord' 'CIS — Require password on wake (battery)'

# --- Miscellaneous hardening ---
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Feeds'          'DisableEnclosureDownload'    1 'DWord' 'CIS 18.9.46.1 — Prevent downloading of enclosures (IE/Edge RSS)'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting'  'Disabled'                    1 'DWord' 'CIS 18.9.81.1 — Disable Windows Error Reporting'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore'                     'RequirePrivateStoreOnly'     1 'DWord' 'CIS 18.9.85.1 — Only use private store in MS Store'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'           'AllowTelemetry'              0 'DWord' 'CIS 18.9.16.1 — Disable telemetry'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'           'DisableOneSettingsDownloads' 1 'DWord' 'CIS — Disable OneSettings downloads'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'     'fAllowToGetHelp'             0 'DWord' 'CIS 18.9.65.2 — Disable Remote Assistance solicited'

# --- DNS over HTTPS (DoH) — Windows 11 native ---
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters' 'EnableAutoDoh' 2 'DWord' 'MS — Enable DNS over HTTPS (DoH)'

# --- Controlled Folder Access ---
Set-MpPreference -EnableControlledFolderAccess Enabled 2>$null
Write-Log 'Controlled Folder Access enabled' 'OK'
$Results.Add([PSCustomObject]@{ Control='Controlled Folder Access'; Status='Applied'; Detail='Ransomware protection' })

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 7 — UNNECESSARY / RISKY SERVICES  (CIS 5.x)
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 7: Unnecessary Services ===' 'INFO'

$servicesToDisable = @(
    @('Browser',       'CIS 5.1 — Computer Browser'),
    @('IISADMIN',      'CIS 5.3 — IIS Admin'),
    @('irmon',         'CIS 5.4 — Infrared Monitor'),
    @('SharedAccess',  'CIS 5.5 — Internet Connection Sharing'),
    @('LxssManager',   'CIS 5.6 — Linux Subsystem (WSL)'),
    @('FTPSVC',        'CIS 5.7 — FTP Server'),
    @('sshd',          'CIS 5.8 — OpenSSH Server (disable if not needed)'),
    @('RpcLocator',    'CIS 5.12 — Remote Procedure Call Locator'),
    @('RemoteRegistry','CIS 5.14 — Remote Registry'),
    @('RemoteAccess',  'CIS 5.19 — Routing and Remote Access'),
    @('simptcp',       'CIS 5.20 — Simple TCP/IP Services'),
    @('SNMP',          'CIS 5.22 — SNMP Service'),
    @('sacsvr',        'CIS 5.24 — Special Administration Console Helper'),
    @('SSDPSRV',       'CIS 5.25 — SSDP Discovery'),
    @('upnphost',      'CIS 5.26 — UPnP Device Host'),
    @('WMSvc',         'CIS 5.27 — Web Management Service'),
    @('WMPNetworkSvc', 'CIS 5.29 — Windows Media Player Network Sharing'),
    @('icssvc',        'CIS 5.30 — Windows Mobile Hotspot'),
    @('WpnService',    'CIS 5.31 — Windows Push Notifications System'),
    @('WerSvc',        'CIS 5.34 — Windows Error Reporting'),
    @('Fax',           'CIS 5.36 — Fax'),
    @('TlntSvr',       'Telnet Server'),
    @('W3SVC',         'IIS World Wide Web Publishing')
)

foreach ($svc in $servicesToDisable) { Disable-ServiceSafe $svc[0] $svc[1] }

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 8 — WINDOWS UPDATE & PATCHING
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 8: Windows Update Policy ===' 'INFO'

$wuBase = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
Set-RegistryValue "$wuBase\AU" 'NoAutoRebootWithLoggedOnUsers' 1 'DWord' 'WU — No auto-reboot with users logged on'
Set-RegistryValue "$wuBase\AU" 'AutoInstallMinorUpdates'       1 'DWord' 'WU — Auto install minor updates'
Set-RegistryValue "$wuBase"    'SetDisablePauseUXAccess'       1 'DWord' 'CIS — Disable user pause of Windows Update'
Set-RegistryValue "$wuBase"    'ManagePreviewBuilds'           1 'DWord' 'CIS 18.9.101.1.1 — Disable preview builds'
Set-RegistryValue "$wuBase"    'DeferFeatureUpdates'           1 'DWord' 'CIS 18.9.101.3.2 — Defer feature updates'
Set-RegistryValue "$wuBase"    'DeferFeatureUpdatesPeriodInDays' 180 'DWord' 'Defer feature updates 180 days'
Set-RegistryValue "$wuBase"    'DeferQualityUpdates'           1 'DWord' 'CIS 18.9.101.3.3 — Defer quality updates'
Set-RegistryValue "$wuBase"    'DeferQualityUpdatesPeriodInDays' 0 'DWord' 'Apply quality/security updates immediately'

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 9 — POWERSHELL HARDENING  (CIS 18.9.x)
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 9: PowerShell Hardening ===' 'INFO'

Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging'   'EnableScriptBlockLogging'         1 'DWord' 'CIS 18.9.97.1 — Enable PowerShell script block logging'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging'   'EnableScriptBlockInvocationLogging' 1 'DWord' 'CIS — Enable script block invocation logging'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription'        'EnableTranscripting'              1 'DWord' 'CIS 18.9.97.2 — Enable PowerShell transcription'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging'        'EnableModuleLogging'              1 'DWord' 'CIS 18.9.97.3 — Enable PS module logging'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell'                      'ExecutionPolicy'            'RemoteSigned' 'String' 'PS Execution Policy: RemoteSigned'

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 10 — BITLOCKER READINESS CHECK
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 10: BitLocker Readiness Check ===' 'INFO'

$tpm = Get-WmiObject Win32_Tpm -Namespace 'root\cimv2\security\microsofttpm' -ErrorAction SilentlyContinue
if ($tpm -and $tpm.IsEnabled_InitialValue) {
    $blStatus = manage-bde -status C: 2>$null
    if ($blStatus -match 'Protection On') {
        Write-Log 'BitLocker is ACTIVE on C:' 'OK'
        $Results.Add([PSCustomObject]@{ Control='BitLocker'; Status='Active'; Detail='C: drive protected' })
    } else {
        Write-Log 'BitLocker NOT active on C: — consider enabling: manage-bde -on C: -SkipHardwareTest' 'WARN'
        $Results.Add([PSCustomObject]@{ Control='BitLocker'; Status='WARNING — Not Active'; Detail='Enable manually: manage-bde -on C: -SkipHardwareTest' })
    }
} else {
    Write-Log 'TPM not found or not enabled — BitLocker with TPM not available' 'WARN'
    $Results.Add([PSCustomObject]@{ Control='BitLocker/TPM'; Status='WARNING'; Detail='TPM not detected or not enabled in BIOS/UEFI' })
}

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 11 — ADDITIONAL MS SECURITY BASELINE SETTINGS
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== SECTION 11: Additional MS Security Baseline ===' 'INFO'

# Block MS accounts for modern auth apps
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'NoConnectedUser' 3 'DWord' 'MS Baseline — Block Microsoft accounts'

# Safe DLL search
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'SafeDllSearchMode' 1 'DWord' 'MS Baseline — Safe DLL search mode'

# Structured Exception Handling Overwrite Protection (SEHOP)
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' 'DisableExceptionChainValidation' 0 'DWord' 'MS Baseline — Enable SEHOP'

# Disable AutoAdminLogon
Set-RegistryValue 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'AutoAdminLogon' '0' 'String' 'MS Baseline — Disable auto admin logon'

# Always prompt for password on resume from screensaver
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization' 'NoLockScreen' 0 'DWord' 'MS — Do not disable lock screen'

# Disable anonymous SID/Name translation
Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'TurnOffAnonymousBlock' 1 'DWord' 'MS — Block anonymous SID/Name translation'

# Disable Windows Installer always-elevated
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer' 'AlwaysInstallElevated' 0 'DWord' 'CIS 18.9.85.1 — Disable AlwaysInstallElevated'
Set-RegistryValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\Installer' 'AlwaysInstallElevated' 0 'DWord' 'CIS 18.9.85.1 — Disable AlwaysInstallElevated (User)'

# Disable Solicited Remote Assistance
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' 'fAllowToGetHelp'          0 'DWord' 'CIS 18.9.65.2.1 — No solicited Remote Assistance'
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' 'fAllowUnsolicited'        0 'DWord' 'CIS 18.9.65.2.2 — No unsolicited Remote Assistance'

# Harden Network Provider order / disable LLMNR
Set-RegistryValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' 'EnableMulticast' 0 'DWord' 'CIS — Disable LLMNR'

# Disable IPv6 if not required (comment out if IPv6 in use)
# Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' 'DisabledComponents' 0xFF 'DWord' 'Disable IPv6'

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 12 — SUMMARY REPORT
# ─────────────────────────────────────────────────────────────────────────────
Write-Log '=== GENERATING SUMMARY REPORT ===' 'INFO'

$total   = $Results.Count
$applied = ($Results | Where-Object { $_.Status -in 'Applied','Disabled','Active' }).Count
$warned  = ($Results | Where-Object { $_.Status -like 'WARNING*' -or $_.Status -eq 'Not Found/Error' }).Count
$failed  = ($Results | Where-Object { $_.Status -eq 'FAILED' }).Count

$summary = @"
================================================================================
  WINDOWS 11 HARDENING REPORT — $(Get-Date -Format 'dd MMM yyyy HH:mm')
  Based on: CIS Win11 Benchmark v3.0 L1 + Microsoft Security Baseline
================================================================================
  Total Controls Processed : $total
  Applied / Active         : $applied
  Warnings (review needed) : $warned
  Failed                   : $failed
  Log File                 : $LogFile
================================================================================
CONTROL DETAILS:
"@

$Results | Format-Table -AutoSize | Out-String | ForEach-Object { $summary += $_ }

$summary += @"

================================================================================
POST-HARDENING ACTIONS (manual):
  1. RESTART the computer for all settings to take effect.
  2. BITLOCKER: Run 'manage-bde -on C: -SkipHardwareTest' if not already enabled.
  3. MFA/WINDOWS HELLO: Enroll via Settings > Accounts > Sign-in options.
  4. APPLOCKER / WDAC: Deploy application allow-listing policy separately.
  5. REVIEW disabled services — re-enable sshd/WinRM if remote management needed.
  6. DOMAIN-JOINED PCs: Verify no GPO conflicts with local settings applied here.
  7. DEFENDER ATP: Onboard to Microsoft Defender for Endpoint if licensed.
================================================================================
"@

Write-Host $summary
Add-Content -Path $LogFile -Value $summary

# Export results to CSV alongside log
$csvPath = $LogFile -replace '\.txt$','.csv'
$Results | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
Write-Log "CSV report saved: $csvPath" 'OK'
Write-Log 'Hardening complete. PLEASE RESTART.' 'OK'
